import 'package:enzi_hardware_store/providers/theme_provide.dart';
import 'package:enzi_hardware_store/screens/splash_screen.dart';
import 'package:enzi_hardware_store/utils/theme.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

void main() async {
  // Initialize supabase
  await Supabase.initialize(
    url: 'https://asalkbffrpqbnldbohzp.supabase.co',
    anonKey:
        'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImFzYWxrYmZmcnBxYm5sZGJvaHpwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzkwMTA4MTUsImV4cCI6MjA1NDU4NjgxNX0.BjPOJE0XHrTIAts7_RZC_Hlw9JZYQeH-S99OTWMyZ9s',
    debug: true,
  );
  runApp(ChangeNotifierProvider(
      create: (context) => ThemeProvide(), child: const MainApp()));
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: Provider.of<ThemeProvide>(context).themeData,
      home: const SplashScreen(),
    );
  }
}
