import 'package:enzi_hardware_store/screens/detailscreen/productdetails.dart';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class ProductCard extends StatefulWidget {
  final int productId;
  final String imageUrl;
  final String name;
  final double price;

  const ProductCard({
    Key? key,
    required this.productId,
    required this.imageUrl,
    required this.name,
    required this.price,
  }) : super(key: key);

  @override
  _ProductCardState createState() => _ProductCardState();
}

class _ProductCardState extends State<ProductCard> {
  bool isWishlisted = false;
  final supabase = Supabase.instance.client;

  @override
  void initState() {
    super.initState();
    _checkIfWishlisted();
  }

  /// CHECK IF PRODUCT IS IN WISHLIST
  Future<void> _checkIfWishlisted() async {
    final response = await supabase
        .from('wishlist')
        .select('product_id')
        .eq('product_id', widget.productId)
        .maybeSingle();

    setState(() {
      isWishlisted = response != null;
    });
  }

  /// TOGGLE WISHLIST IN SUPABASE
  Future<void> _toggleWishlist() async {
    final user_id = supabase.auth.currentUser!.id;

    if (isWishlisted) {
      await supabase
          .from('wishlist')
          .delete()
          .eq('product_id', widget.productId);
    } else {
      await supabase.from('wishlist').insert({
        'product_id': widget.productId,
        'user_id': user_id,
        'added_at': DateTime.now().toUtc().toIso8601String(),
      });
    }

    setState(() {
      isWishlisted = !isWishlisted;
    });
  }

  /// ADD TO CART FUNCTION
  Future<void> _addToCart() async {
    final user = supabase.auth.currentUser;
    if (user == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please log in to add items to the cart")),
      );
      return;
    }

    // FETCH PRODUCT DETAILS TO CHECK FOR VARIANTS
    final productData = await supabase
        .from('products')
        .select('variant') // FETCH VARIANTS COLUMN
        .eq('product_id', widget.productId)
        .maybeSingle();

    String variantToAdd = '';

    if (productData != null &&
        productData['variant'] is List &&
        productData['variant'].isNotEmpty) {
      variantToAdd = productData['variant'][0]; // PICK FIRST VARIANT
    }

    // CHECK IF PRODUCT IS ALREADY IN CART
    final existingCartItem = await supabase
        .from('cart')
        .select('quantity')
        .eq('user_id', user.id)
        .eq('product_id', widget.productId)
        .eq('variant', variantToAdd)
        .maybeSingle();

    if (existingCartItem != null) {
      // UPDATE QUANTITY IF PRODUCT IS ALREADY IN CART
      await supabase
          .from('cart')
          .update({'quantity': existingCartItem['quantity'] + 1})
          .eq('user_id', user.id)
          .eq('product_id', widget.productId)
          .eq('variant', variantToAdd);
    } else {
      // INSERT NEW ITEM INTO CART
      await supabase.from('cart').insert({
        'user_id': user.id,
        'product_id': widget.productId,
        'variant': variantToAdd, // STORE SELECTED OR DEFAULT VARIANT
        'quantity': 1,
        'price': widget.price,
        'created_at': DateTime.now().toUtc().toIso8601String(),
        'updated_at': DateTime.now().toUtc().toIso8601String(),
      });
    }

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Added to cart!")),
    );
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        // NAVIGATE TO PRODUCT DETAILS PAGE WITH EXISTING DATA
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => ProductDetailPage(
              productId: widget.productId,
            ),
          ),
        );
      },
      child: LayoutBuilder(
        builder: (context, constraints) {
          return Card(
            elevation: 6,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            child: Column(
              mainAxisSize: MainAxisSize.max,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // PRODUCT IMAGE
                ClipRRect(
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(12),
                    topRight: Radius.circular(12),
                  ),
                  child: Image.network(
                    widget.imageUrl,
                    height: constraints.maxWidth * 0.55, // RESPONSIVE HEIGHT
                    width: double.infinity,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) => Container(
                      height: constraints.maxWidth * 0.55,
                      color: Theme.of(context).cardColor,
                      child:
                          const Icon(Icons.image, size: 50, color: Colors.grey),
                    ),
                  ),
                ),

                // PRODUCT DETAILS CONTAINER
                Flexible(
                  child: Padding(
                    padding: const EdgeInsets.all(6.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // PRODUCT NAME
                        Text(
                          widget.name,
                          style: const TextStyle(fontSize: 14),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        const SizedBox(height: 4),
                        // PRODUCT PRICE
                        Text(
                          "Kshs. ${widget.price.toStringAsFixed(0)}",
                          style: const TextStyle(
                              fontSize: 16, fontWeight: FontWeight.bold),
                        ),

                        // BUTTONS ROW (WISHLIST & ADD TO CART)
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 4.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              // ADD TO CART BUTTON
                              Expanded(
                                child: ElevatedButton(
                                  onPressed: _addToCart,
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor:
                                        Theme.of(context).primaryColor,
                                    foregroundColor: Colors.white,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                  ),
                                  child: const Text("Add to cart",
                                      style: TextStyle(fontSize: 12)),
                                ),
                              ),
                              const SizedBox(width: 4),
                              // WISHLIST BUTTON
                              IconButton(
                                onPressed: _toggleWishlist,
                                icon: Icon(
                                  isWishlisted
                                      ? Icons.favorite
                                      : Icons.favorite_border,
                                  color: isWishlisted
                                      ? Theme.of(context).primaryColor
                                      : Colors.grey,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
