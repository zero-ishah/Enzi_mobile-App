import 'package:flutter/material.dart';

class TermsConditions extends StatefulWidget {
  const TermsConditions({super.key});

  @override
  State<TermsConditions> createState() => _TermsConditionsState();
}

class _TermsConditionsState extends State<TermsConditions> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Terms & Conditions'),
      ),
      body: const SingleChildScrollView(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Terms and Conditions',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 16),
            Text(
              '1. Introduction',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8),
            Text(
              'Welcome to our mobile application. By accessing or using our app, you agree to be bound by these terms and conditions. Please read them carefully.',
            ),
            SizedBox(height: 16),
            Text(
              '2. Use of the App',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8),
            Text(
              'You agree to use the app only for lawful purposes and in a way that does not infringe the rights of, restrict, or inhibit anyone else\'s use and enjoyment of the app.',
            ),
            SizedBox(height: 16),
            Text(
              '3. User Accounts',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8),
            Text(
              'To access certain features of the app, you may need to create an account. You are responsible for maintaining the confidentiality of your account information and for all activities that occur under your account.',
            ),
            SizedBox(height: 16),
            Text(
              '4. Privacy Policy',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8),
            Text(
              'We are committed to protecting your privacy. Our privacy policy, which sets out how we will use your information, can be found within the app settings or on our website.',
            ),
            SizedBox(height: 16),
            Text(
              '5. Products',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8),
            Text(
              'All products listed on our app are subject to availability. We reserve the right to discontinue any product at any time without notice.',
            ),
            SizedBox(height: 16),
            Text(
              '6. Orders',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8),
            Text(
              'By placing an order through our app, you agree to provide accurate and complete information. We reserve the right to refuse or cancel any order at any time for reasons including but not limited to product availability, errors in the description or price of the product, or any other issue identified by our team.',
            ),
            SizedBox(height: 16),
            Text(
              '7. Payment',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8),
            Text(
              'All payments must be made through the provided payment methods on the app. We are not responsible for any issues arising from third-party payment providers.',
            ),
            SizedBox(height: 16),
            Text(
              '8. Shipping and Delivery',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8),
            Text(
              'We will make every effort to deliver your order within the estimated delivery time. However, delivery times are not guaranteed and may be affected by factors beyond our control.',
            ),
            SizedBox(height: 16),
            Text(
              '9. Returns and Refunds',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8),
            Text(
              'If you are not satisfied with your purchase, you may return the product within the specified return period for a refund or exchange, subject to our return policy.',
            ),
            SizedBox(height: 16),
            Text(
              '10. Changes to Terms',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8),
            Text(
              'We reserve the right to change these terms and conditions at any time. Any changes will be posted in the app. Your continued use of the app following the posting of changes will mean you accept those changes.',
            ),
            SizedBox(height: 16),
            Text(
              '11. Limitation of Liability',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8),
            Text(
              'To the fullest extent permitted by law, we shall not be liable for any indirect, incidental, special, or consequential damages arising out of or in connection with your use of the app.',
            ),
            SizedBox(height: 16),
            Text(
              '12. Contact Us',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8),
            Text(
              'If you have any questions about these terms and conditions, please contact us at support@mobileapp.com.',
            ),
          ],
        ),
      ),
    );
  }
}
