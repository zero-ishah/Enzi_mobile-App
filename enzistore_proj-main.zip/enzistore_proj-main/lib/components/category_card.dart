import 'package:flutter/material.dart';

class CategoryCard extends StatelessWidget {
  final String category;
  final String iconUrl;
  final Color bgColor;
  final int categoryId; // CATEGORY ID FOR FILTERING PRODUCTS
  final Function(int) onTap; // FUNCTION TO NAVIGATE

  const CategoryCard({
    Key? key,
    required this.category,
    required this.iconUrl,
    required this.bgColor,
    required this.categoryId,
    required this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => onTap(categoryId), // NAVIGATE TO PRODUCTS PAGE
      child: Column(
        children: [
          Container(
            width: 60,
            height: 60,
            margin: const EdgeInsets.symmetric(horizontal: 8),
            decoration: BoxDecoration(
              color: bgColor,
              borderRadius: BorderRadius.circular(15),
            ),
            child: Center(
              child: Image.network(
                iconUrl,
                width: 40,
                height: 40,
                fit: BoxFit.contain,
                errorBuilder: (context, error, stackTrace) =>
                    const Icon(Icons.category, size: 40, color: Colors.grey),
              ),
            ),
          ),
          const SizedBox(height: 5),
          SizedBox(
            width: 70,
            child: Text(
              category,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w500),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }
}
