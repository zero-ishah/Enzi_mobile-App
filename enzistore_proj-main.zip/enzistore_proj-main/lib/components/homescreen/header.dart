import 'package:enzi_hardware_store/screens/actionscreens/cartpage.dart';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class Header extends StatefulWidget {
  const Header({super.key});

  @override
  State<Header> createState() => _HeaderState();
}

class _HeaderState extends State<Header> {
  String deliveryAddress = "Fetching...";
  int cartItemCount = 0;
  int notificationCount = 0;
  final supabase = Supabase.instance.client;

  @override
  void initState() {
    super.initState();
    _fetchDeliveryAddress();
    _fetchCartItemCount();
    _fetchNotificationCount();
  }

  /// FETCH USER'S DELIVERY ADDRESS
  Future<void> _fetchDeliveryAddress() async {
    final response = await supabase
        .from('users')
        .select('address')
        .maybeSingle(); // FETCH SINGLE USER INFO

    setState(() {
      deliveryAddress = response?['address'] ?? "No Address Set";
    });
  }

  /// FETCH CART ITEM COUNT
  Future<void> _fetchCartItemCount() async {
    final response = await supabase.from('cart').select('*');
    setState(() {
      cartItemCount = response.length;
    });
  }

  /// FETCH NOTIFICATION COUNT
  Future<void> _fetchNotificationCount() async {
    final response = await supabase.from('notification').select('id');
    setState(() {
      notificationCount = response.length;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        // DELIVERY ADDRESS
        Expanded(
          child: Container(
            padding: const EdgeInsets.all(10),
            child: Row(
              children: [
                const Icon(Icons.location_on),
                const SizedBox(width: 5),
                Expanded(
                  child: Text(
                    deliveryAddress,
                    overflow: TextOverflow.ellipsis, // PREVENT OVERFLOW
                    style: const TextStyle(fontSize: 14),
                  ),
                ),
              ],
            ),
          ),
        ),

        // CART WITH COUNTER
        Stack(
          children: [
            IconButton(
              onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) =>
                          CartPage())), // NAVIGATE TO CART PAGE
              icon: const Icon(Icons.shopping_cart),
            ),
            if (cartItemCount > 0)
              Positioned(
                right: 0,
                child: _buildBadge(cartItemCount),
              ),
          ],
        ),

        // NOTIFICATION BELL WITH COUNTER
        Stack(
          children: [
            IconButton(
              onPressed: () {},
              icon: const Icon(Icons.notifications),
            ),
            if (notificationCount > 0)
              Positioned(
                right: 0,
                child: _buildBadge(notificationCount),
              ),
          ],
        ),
      ],
    );
  }

  /// HELPER FUNCTION TO BUILD A BADGE
  Widget _buildBadge(int count) {
    return Container(
      padding: const EdgeInsets.all(5),
      decoration: const BoxDecoration(
        color: Colors.red,
        shape: BoxShape.circle,
      ),
      child: Text(
        count.toString(),
        style: const TextStyle(
          color: Colors.white,
          fontSize: 12,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
}
