import 'package:flutter/material.dart';

// PRIMARY AND ERROR COLORS
const Color primaryColor = Color(0xFF67C4A7);
const Color errorColor = Color(0xFFD65B5B);

// LIGHT THEME
final ThemeData lightTheme = ThemeData(
  brightness: Brightness.light,
  primaryColor: primaryColor,
  colorScheme: const ColorScheme.light(
    primary: primaryColor,
    onPrimary: Colors.white,
    secondary: Colors.teal,
    onSecondary: Colors.white,
    error: errorColor,
    onError: Colors.white,
    surface: Colors.white,
    onSurface: Colors.black,
  ),
  textTheme: lightTextTheme,

// INPUT DECORATION THEME
  inputDecorationTheme: InputDecorationTheme(
    enabledBorder: OutlineInputBorder(
      borderSide: BorderSide(color: Colors.grey.shade700, width: 2.0),
      borderRadius: BorderRadius.circular(10.0),
    ),
    border: OutlineInputBorder(
      borderSide: BorderSide(color: Colors.grey.shade700, width: 2.0),
      borderRadius: BorderRadius.circular(10.0),
    ),
    focusedBorder: OutlineInputBorder(
      borderSide: const BorderSide(color: primaryColor, width: 2.0),
      borderRadius: BorderRadius.circular(10.0),
    ),
    hintStyle: TextStyle(color: Colors.grey.shade700, fontSize: 14.0),
    labelStyle: TextStyle(
        color: Colors.grey.shade900,
        fontSize: 16.0,
        fontFamily: 'poppins',
        fontWeight: FontWeight.w500),
  ),
);

// DARK THEME
final ThemeData darkTheme = ThemeData(
  brightness: Brightness.dark,
  primaryColor: primaryColor,
  colorScheme: const ColorScheme.dark(
    primary: primaryColor,
    onPrimary: Colors.black,
    secondary: Colors.teal,
    onSecondary: Colors.black,
    error: errorColor,
    onError: Colors.black,
    surface: Color(0xFF1E1E1E),
    onSurface: Colors.white,
  ),
  textTheme: darkTextTheme,

  // INPUT DECORATION THEME
  inputDecorationTheme: InputDecorationTheme(
    enabledBorder: OutlineInputBorder(
      borderSide: BorderSide(color: Colors.grey.shade800, width: 2.0),
      borderRadius: BorderRadius.circular(10.0),
    ),
    border: OutlineInputBorder(
      borderSide: BorderSide(color: Colors.grey.shade800, width: 2.0),
      borderRadius: BorderRadius.circular(10.0),
    ),
    focusedBorder: OutlineInputBorder(
      borderSide: const BorderSide(color: primaryColor, width: 2.0),
      borderRadius: BorderRadius.circular(10.0),
    ),
    hintStyle: TextStyle(color: Colors.grey.shade600, fontSize: 14.0),
    labelStyle: TextStyle(
        color: Colors.grey.shade600,
        fontSize: 16.0,
        fontFamily: 'poppins',
        fontWeight: FontWeight.w500),
  ),
);

// LIGHT TEXT THEME
TextTheme lightTextTheme = TextTheme(
  titleLarge: TextStyle(
      fontSize: 28.0,
      fontWeight: FontWeight.bold,
      color: Colors.grey.shade900,
      fontFamily: 'poppins'),
  titleMedium: TextStyle(
      fontSize: 22.0,
      fontWeight: FontWeight.w600,
      color: Colors.grey.shade900,
      fontFamily: 'poppins'),
  titleSmall: TextStyle(
      fontSize: 18.0,
      fontWeight: FontWeight.w500,
      color: Colors.grey.shade900,
      fontFamily: 'poppins'),
  bodyLarge: TextStyle(
      fontSize: 16.0,
      fontWeight: FontWeight.w500,
      color: Colors.grey.shade900,
      fontFamily: 'poppins'),
  bodyMedium: TextStyle(
      fontSize: 14.0,
      fontWeight: FontWeight.w500,
      color: Colors.grey.shade900,
      fontFamily: 'poppins'),
  bodySmall: TextStyle(
      fontSize: 12.0,
      fontWeight: FontWeight.w500,
      color: Colors.grey.shade900,
      fontFamily: 'poppins'),
);

// DARK TEXT THEME
TextTheme darkTextTheme = TextTheme(
  titleLarge: TextStyle(
      fontSize: 28.0,
      fontWeight: FontWeight.bold,
      color: Colors.grey.shade600,
      fontFamily: 'poppins'),
  titleMedium: TextStyle(
      fontSize: 22.0,
      fontWeight: FontWeight.w600,
      color: Colors.grey.shade600,
      fontFamily: 'poppins'),
  titleSmall: TextStyle(
      fontSize: 18.0,
      fontWeight: FontWeight.w500,
      color: Colors.grey.shade600,
      fontFamily: 'poppins'),
  bodyLarge: TextStyle(
      fontSize: 16.0,
      fontWeight: FontWeight.w500,
      color: Colors.grey.shade600,
      fontFamily: 'poppins'),
  bodyMedium: TextStyle(
      fontSize: 14.0,
      fontWeight: FontWeight.w500,
      color: Colors.grey.shade600,
      fontFamily: 'poppins'),
  bodySmall: TextStyle(
      fontSize: 12.0,
      fontWeight: FontWeight.w500,
      color: Colors.grey.shade600,
      fontFamily: 'poppins'),
);
