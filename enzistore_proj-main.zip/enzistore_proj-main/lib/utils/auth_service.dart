import 'package:enzi_hardware_store/screens/Auth/Log_in.dart';
import 'package:enzi_hardware_store/screens/NavScreens/home_screen.dart';
import 'package:enzi_hardware_store/screens/NavScreens/landingscreen.dart';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class AuthService {
  final SupabaseClient _client;

  AuthService(this._client);

  Future<void> signUp(BuildContext context, String email, String password,
      String phone, String firstName, String lastName) async {
    try {
      // STEP 1: AUTHENTICATE USER
      final AuthResponse response = await Supabase.instance.client.auth.signUp(
        email: email,
        password: password,
      );

      if (response.user == null) {
        showPopup(context, 'Sign-up failed. Please try again.', false);
        return;
      }

      final String userId = response.user!.id;

      // STEP 2: INSERT INTO USERS TABLE
      await Supabase.instance.client.from('users').insert({
        'user_id': userId,
        'first_name': firstName,
        'last_name': lastName,
        'email': email,
        'phone': phone,
        'created_at': DateTime.now().toUtc().toIso8601String(),
      });

      // STEP 3: SUCCESS MESSAGE & REDIRECT
      showPopup(context, 'Sign-up successful! Welcome, $firstName.', true,
          onSuccess: () {
        Future.delayed(Duration(milliseconds: 300), () {
          Navigator.pushReplacement(
              context, MaterialPageRoute(builder: (context) => const LogIn()));
        }); // Redirect to login
      });
    } catch (error) {
      showPopup(context, 'Error during sign-up: ${error.toString()}', false);
    }
  }

  Future<void> login(
      BuildContext context, String email, String password) async {
    try {
      final AuthResponse response = await Supabase.instance.client.auth
          .signInWithPassword(email: email, password: password);

      if (response.user == null) {
        showPopup(
            context, 'Login failed. Please check your credentials.', false);
        return;
      }

      showPopup(context, 'Login successful! Welcome back.', true,
          onSuccess: () {
        Navigator.pushReplacement(
            context,
            MaterialPageRoute(
                builder: (context) =>
                    LandingScreen())); // Redirect to Home Page
      });
    } catch (error) {
      showPopup(context, 'Error during login: ${error.toString()}', false);
    }
  }

  Future<void> resetPassword(BuildContext context, String email) async {
    if (email.trim().isEmpty) {
      showPopup(context, 'Please enter your email address.', false);
      return;
    }

    try {
      await Supabase.instance.client.auth.resetPasswordForEmail(email);
      showPopup(context, 'Password reset email sent. Check your inbox.', true);
    } catch (error) {
      showPopup(context, 'Error: ${error.toString()}', false);
    }
  }

  /// FUNCTION TO SHOW POPUP WITH ICON AND MESSAGE
  void showPopup(BuildContext context, String message, bool isSuccess,
      {VoidCallback? onSuccess}) {
    showDialog(
      context: context,
      barrierDismissible: false, // Prevent closing by tapping outside
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(
            isSuccess ? 'Success' : 'Error',
            textAlign: TextAlign.center,
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                isSuccess ? Icons.check_circle : Icons.error,
                color: isSuccess ? Colors.green : Colors.red,
                size: 50,
              ),
              SizedBox(height: 10),
              Text(message, textAlign: TextAlign.center),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context); // Close the dialog first
                if (isSuccess && onSuccess != null) {
                  Future.delayed(Duration(milliseconds: 300),
                      onSuccess); // Smooth transition
                }
              },
              child: Text('OK', style: TextStyle(color: Colors.blue)),
            ),
          ],
        );
      },
    );
  }

  Future<void> signOut(BuildContext context) async {
    try {
      await _client.auth.signOut();
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (context) => const LogIn()));
    } catch (e) {
      showPopup(context, 'Error: ${e.toString()}', false);
    }
  }
}
