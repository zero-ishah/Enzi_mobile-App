import 'package:enzi_hardware_store/components/custom_button.dart';
import 'package:enzi_hardware_store/screens/Auth/forgot_password.dart';
import 'package:enzi_hardware_store/screens/Auth/sign_up.dart';
import 'package:enzi_hardware_store/utils/auth_service.dart';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class LogIn extends StatefulWidget {
  const LogIn({super.key});

  @override
  State<LogIn> createState() => _LogInState();
}

class _LogInState extends State<LogIn> {
  /////////////////////////////// VARIABLES SECTION ////////////////////////////
  // EMAIL CONTROLLER
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController =
      TextEditingController(); // PASSWORD CONTROLER

  final SupabaseClient _client = Supabase.instance.client;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: ListView(
            children: [
              // ENZI STORE ILLUSTRATION IMAGE
              Align(
                child: Image.asset(
                  'assets/images/furniturestore.png',
                  height: 250,
                ),
              ),

              //WELCOME TEXT
              Text(
                'Welcome!',
                style: Theme.of(context).textTheme.titleLarge,
              ),
              Text(
                'We are glad to see you again!',
                style: Theme.of(context).textTheme.bodyLarge,
              ),

              Text(
                'To continue, please login to your account',
                style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                      color: Colors.grey.shade500,
                    ),
              ),

              // LOGIN FORM
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  children: [
                    // EMAIL INPUT
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 10.0),
                      child: TextFormField(
                        controller: emailController,
                        decoration: const InputDecoration(
                          labelText: 'Email',
                          hintText: 'Enter your email',
                        ),
                      ),
                    ),

                    // PASSWORD INPUT
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 10.0),
                      child: TextFormField(
                        controller: passwordController,
                        decoration: const InputDecoration(
                          labelText: 'Password',
                          hintText: 'Enter your password',
                        ),
                      ),
                    ),

                    // FORGOT PASSWORD
                    Align(
                      alignment: Alignment.centerRight,
                      child: TextButton(
                        onPressed: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => ForgotPasswordPage()));
                        },
                        child: const Text('Forgot Password?'),
                      ),
                    ),

                    // LOGIN BUTTON
                    CustomButton(
                        text: 'Log In',
                        onPressed: () {
                          // LOGIN FUNCTIONALITY
                          // if fields are empty show pop up with error icon
                          if (emailController.text.trim().isEmpty ||
                              passwordController.text.trim().isEmpty) {
                            AuthService(_client).showPopup(context,
                                'Please enter both email and password.', false);
                            return;
                          }
                          AuthService(_client).login(
                              context,
                              emailController.text.trim(),
                              passwordController.text.trim());
                        }),

                    // REGISTER FOR ACCOUNT
                    Row(
                      children: [
                        const Text('Don\'t have an account?'),
                        TextButton(
                            onPressed: () => Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => SignUpPage())),
                            child: const Text('Sign Up')),
                      ],
                    ),

                    // OR
                    const Row(
                      children: [
                        Expanded(
                          child: Divider(),
                        ),
                        Padding(
                          padding: EdgeInsets.all(8.0),
                          child: Text('OR'),
                        ),
                        Expanded(
                          child: Divider(),
                        ),
                      ],
                    ),

                    // Google and Apple Sign In
                    Row(
                      children: [
                        Expanded(
                          child: CustomButton(
                            text: 'Google',
                            onPressed: () {
                              // GOOGLE SIGN IN FUNCTIONALITY
                            },
                          ),
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        Expanded(
                          child: CustomButton(
                            text: 'Apple ID',
                            onPressed: () {
                              // APPLE SIGN IN FUNCTIONALITY
                            },
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
