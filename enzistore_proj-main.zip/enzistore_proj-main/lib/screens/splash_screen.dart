import 'package:flutter/material.dart';
import 'package:loading_indicator/loading_indicator.dart';
import 'Auth/Log_in.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    routeToScreen();
    super.initState();
  }

  routeToScreen() {
    Future.delayed(const Duration(seconds: 3), () {
      // CHECK FOR STORED SESSION TO GO TO HOME DIRECT

      // NAVIGATE TO LOGIN AND
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (context) => LogIn()));
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SizedBox(
        width: double.infinity,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            // ENZI STORE ILLUSTRATION IMAGE
            Image.asset('assets/images/windowshopping.png'),

            // COMPANY NAME
            Text('ENZI HARDWARE STORE'),

            // LOADING SPINNER
            const Padding(
              padding: EdgeInsets.all(8.0),
              child: SizedBox(
                  width: 70,
                  child: LoadingIndicator(
                      indicatorType: Indicator.ballSpinFadeLoader)),
            ),
          ],
        ),
      ),
    );
  }
}
