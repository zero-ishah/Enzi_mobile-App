import 'package:enzi_hardware_store/screens/actionscreens/cartpage.dart';
import 'package:enzi_hardware_store/screens/actionscreens/checkout.dart';
import 'package:enzi_hardware_store/utils/auth_service.dart';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class ProductDetailPage extends StatefulWidget {
  final int productId;

  const ProductDetailPage({super.key, required this.productId});

  @override
  State<ProductDetailPage> createState() => _ProductDetailPageState();
}

class _ProductDetailPageState extends State<ProductDetailPage> {
  final supabase = Supabase.instance.client;
  Map<String, dynamic>? product;
  List<String> variants = [];
  String selectedVariant = "";

  @override
  void initState() {
    super.initState();
    _fetchProductDetails();
  }

  /// FETCH PRODUCT DETAILS FROM SUPABASE
  Future<void> _fetchProductDetails() async {
    final response = await supabase
        .from('products')
        .select('*')
        .eq('product_id', widget.productId)
        .maybeSingle();

    if (response != null) {
      setState(() {
        product = response;
        variants = List<String>.from(response['variant'] ?? []);
        selectedVariant = variants.isNotEmpty ? variants[0] : "";
      });
    }
  }

  Future<void> _addToCart() async {
    if (product == null) return;

    try {
      // GET THE USER ID (ASSUMING USER IS LOGGED IN)
      final user = supabase.auth.currentUser;
      if (user == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
              content: Text("Please log in to add items to your cart.")),
        );
        return;
      }

      final userId = user.id;
      final productPrice = product!['selling_price'];

      // CHECK IF ITEM ALREADY EXISTS IN CART
      final existingCartItem = await supabase
          .from('cart')
          .select('cart_id, quantity')
          .eq('user_id', userId)
          .eq('product_id', widget.productId)
          .eq('variant', selectedVariant)
          .maybeSingle();

      if (existingCartItem != null) {
        // ITEM EXISTS, INCREMENT QUANTITY & UPDATE TIMESTAMP
        await supabase.from('cart').update({
          'quantity': existingCartItem['quantity'] + 1,
          'updated_at':
              DateTime.now().toUtc().toIso8601String(), // UPDATE TIMESTAMP
        }).eq('cart_id', existingCartItem['cart_id']);
      } else {
        // ITEM DOES NOT EXIST, ADD NEW ENTRY
        await supabase.from('cart').insert({
          'user_id': userId,
          'product_id': widget.productId,
          'variant': selectedVariant,
          'quantity': 1,
          'price': productPrice,
          'created_at': DateTime.now().toUtc().toIso8601String(),
          'updated_at': DateTime.now().toUtc().toIso8601String(),
        });
      }

      // SHOW SUCCESS MESSAGE
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Added to cart!")),
      );
      // Route to cart page
      Navigator.push(
          context, MaterialPageRoute(builder: (context) => CartPage()));
    } catch (e) {
      AuthService(supabase)
          .showPopup(context, 'Error adding to cart: $e', false);

      print('Error adding to cart: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    if (product == null) {
      return const Center(child: CircularProgressIndicator());
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text("Details product"),
        actions: [
          IconButton(
            icon: const Icon(Icons.shopping_cart),
            onPressed: ()=> Navigator.push(
          context, MaterialPageRoute(builder: (context) => CartPage())), // NAVIGATE TO CART PAGE
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // PRODUCT IMAGE
            Image.network(
              product!['image_url'] ?? '',
              height: 250,
              width: double.infinity,
              fit: BoxFit.cover,
            ),

            const SizedBox(height: 16),

            // PRODUCT NAME & PRICE
            Text(
              product!['name'] ?? '',
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            Text(
              "Kshs. ${product!['selling_price']}",
              style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.green),
            ),

            const SizedBox(height: 10),

            // PRODUCT VARIANTS
            const Text("Choose the variant", style: TextStyle(fontSize: 16)),
            const SizedBox(height: 10),
            Wrap(
              spacing: 8,
              children: variants.map((variant) {
                return ChoiceChip(
                  label: Text(variant),
                  selected: selectedVariant == variant,
                  onSelected: (selected) {
                    setState(() {
                      selectedVariant = variant;
                    });
                  },
                );
              }).toList(),
            ),

            const SizedBox(height: 20),

            // PRODUCT DESCRIPTION
            const Text("Description",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            Text(product!['description'] ?? '',
                style: const TextStyle(fontSize: 16)),

            const SizedBox(height: 20),

            // ADD TO CART & BUY NOW BUTTONS
            Row(
              children: [
                Expanded(
                  child: ElevatedButton(
                    onPressed: _addToCart,
                    style: ElevatedButton.styleFrom(
                        foregroundColor: Colors.white,
                        backgroundColor: Theme.of(context).primaryColor),
                    child: const Text("Add to Cart"),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: OutlinedButton(
                    onPressed: () {
                      if (product == null) return;

                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => CheckoutPage(
                            productId: widget.productId,
                            productName: product!['name'] ?? '',
                            productPrice:
                                product!['selling_price']?.toDouble() ?? 0.0,
                            productImage: product!['image_url'] ?? '',
                            selectedVariant: selectedVariant,
                          ),
                        ),
                      );
                    },
                    child: const Text("Buy Now"),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
