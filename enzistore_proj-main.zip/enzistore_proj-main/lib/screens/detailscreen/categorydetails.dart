import 'package:enzi_hardware_store/components/product_card.dart';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class CategoryProductsPage extends StatefulWidget {
  final int categoryId;
  final String categoryName; // CATEGORY NAME FOR TITLE

  const CategoryProductsPage({
    Key? key,
    required this.categoryId,
    required this.categoryName,
  }) : super(key: key);

  @override
  _CategoryProductsPageState createState() => _CategoryProductsPageState();
}

class _CategoryProductsPageState extends State<CategoryProductsPage> {
  final SupabaseClient supabase = Supabase.instance.client;
  List<Map<String, dynamic>> products = [];

  @override
  void initState() {
    super.initState();
    fetchProducts();
  }

  Future<void> fetchProducts() async {
    try {
      final response = await supabase
          .from('products')
          .select('*')
          .eq('category', widget.categoryId);

      // if (mounted) {
      setState(() {
        products = List<Map<String, dynamic>>.from(response);
        print(widget.categoryName);
        print(widget.categoryId);
      });
      // }
    } catch (error) {
      print(error);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:
          AppBar(title: Text(widget.categoryName)), // CATEGORY NAME AS TITLE
      body: products.isEmpty
          ? const Center(child: CircularProgressIndicator())
          : GridView.builder(
              padding: const EdgeInsets.all(10),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                childAspectRatio: 0.8,
              ),
              itemCount: products.length,
              itemBuilder: (context, index) {
                final product = products[index];
                return ProductCard(
                  name: product['name'] ?? 'Unknown',
                  imageUrl: product['image_url'] ?? '',
                  price: double.tryParse(
                          product['selling_price']?.toString() ?? '0') ??
                      0, // CONVERT TO DOUBLE
                  productId: product['id'] ?? 0,
                  
                );
              },
            ),
    );
  }
}
