import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class DeliveryAddressPage extends StatefulWidget {
  @override
  _DeliveryAddressPageState createState() => _DeliveryAddressPageState();
}

class _DeliveryAddressPageState extends State<DeliveryAddressPage> {
  final SupabaseClient _supabaseClient = Supabase.instance.client;

  final TextEditingController _addressController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  bool _isLoading = false;
  bool _hasAddress = false; // CHECK IF ADDRESS EXISTS

  @override
  void initState() {
    super.initState();
    _fetchDeliveryInfo();
  }

  Future<void> _fetchDeliveryInfo() async {
    try {
      final userId = _supabaseClient.auth.currentUser?.id;
      if (userId == null) return;

      final response = await _supabaseClient
          .from('users')
          .select('address')
          .eq('user_id', userId)
          .maybeSingle();

      if (response != null && response['address'] != null) {
        List<dynamic> deliveryInfo = response['address'];

        if (deliveryInfo.isNotEmpty) {
          _addressController.text = deliveryInfo[0] ?? '';
          _phoneController.text =
              deliveryInfo.length > 1 ? deliveryInfo[1] : '';

          setState(() {
            _hasAddress = _addressController.text.isNotEmpty;
          });
        }
      }
    } catch (e) {
      print('Error fetching delivery info: $e');
    }
  }

  Future<void> _updateDeliveryInfo() async {
    if (_addressController.text.isEmpty || _phoneController.text.isEmpty)
      return;

    setState(() => _isLoading = true);
    try {
      final userId = _supabaseClient.auth.currentUser?.id;
      if (userId == null) return;

      // STORE AS JSONB ARRAY IN DATABASE
      final List<String> deliveryInfo = [
        _addressController.text,
        _phoneController.text
      ];

      await _supabaseClient
          .from('users')
          .update({'address': deliveryInfo}).eq('user_id', userId);

      setState(() {
        _hasAddress = true;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Delivery info updated successfully!')),
      );
    } catch (e) {
      print('Error updating delivery info: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to update. Please try again.')),
      );
    } finally {
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Delivery Information')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (!_hasAddress) ...[
              TextField(
                controller: _addressController,
                decoration: InputDecoration(
                  labelText: 'Enter Delivery Address',
                  border: OutlineInputBorder(),
                ),
              ),
              SizedBox(height: 16.0),
              TextField(
                controller: _phoneController,
                keyboardType: TextInputType.phone,
                decoration: InputDecoration(
                  labelText: 'Enter Phone Number',
                  border: OutlineInputBorder(),
                ),
              ),
              SizedBox(height: 16.0),
              ElevatedButton(
                onPressed: _isLoading ? null : _updateDeliveryInfo,
                child: _isLoading
                    ? CircularProgressIndicator(color: Colors.white)
                    : Text('Save Address'),
              ),
            ] else ...[
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Delivery Address: ${_addressController.text}",
                          style: TextStyle(fontSize: 16)),
                      Text("Phone Number: ${_phoneController.text}",
                          style: TextStyle(fontSize: 16)),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 16.0),
              ElevatedButton(
                onPressed: () {
                  setState(() {
                    _hasAddress = false; // ENABLE UPDATE MODE
                  });
                },
                child: Text("Update Address"),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
