import 'package:enzi_hardware_store/utils/auth_service.dart';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class OrderDetails extends StatefulWidget {
  final int orderId;
  OrderDetails({required this.orderId});

  @override
  _OrderDetailsState createState() => _OrderDetailsState();
}

class _OrderDetailsState extends State<OrderDetails> {
  final supabase = Supabase.instance.client;

  Future<Map<String, dynamic>> fetchOrderDetails() async {
    try {
      final response = await supabase
          .from('orders')
          .select(
              'order_id, tracking_number, total_amount, order_status, payment_status, order_date')
          .eq('order_id', widget.orderId)
          .single();

      final orderItemsResponse = await supabase
          .from('order_items')
          .select(
              'product_id, quantity, selling_price, products(name, image_url)')
          .eq('order_id', widget.orderId)
          .order('product_id', ascending: true);

      response['items'] = orderItemsResponse;

      print('orderItemresponse $orderItemsResponse');
      return response;
    } catch (e) {
      AuthService(supabase)
          .showPopup(context, 'Error Loading order details $e', false);
      return {};
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Order Details')),
      body: FutureBuilder<Map<String, dynamic>>(
        future: fetchOrderDetails(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(child: Text('Error loading order details'));
          }
          final order = snapshot.data!;
          final items = order['items'] as List;

          return Padding(
            padding: EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("Tracking Number: ${order['tracking_number']}",
                    style:
                        TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                Text("Total Amount: Ksh ${order['total_amount']}"),
                Text("Status: ${order['order_status']}",
                    style: TextStyle(color: Colors.blue)),
                SizedBox(height: 20),
                Text("Products",
                    style:
                        TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                Expanded(
                  child: ListView.builder(
                    itemCount: items.length,
                    itemBuilder: (context, index) {
                      final item = items[index];
                      return Card(
                        margin: EdgeInsets.symmetric(vertical: 8),
                        child: ListTile(
                          leading: Image.network(item['products']['image_url'],
                              width: 50, height: 50, fit: BoxFit.cover),
                          title: Text(item['products']['name']),
                          subtitle: Text(
                              "Qty: ${item['quantity']}  |  Price: Ksh ${item['selling_price']}"),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
