import 'dart:convert';
import 'package:enzi_hardware_store/components/custom_button.dart';
import 'package:flutter/material.dart';

class DeliveryAddressStep extends StatefulWidget {
  final Function(String)? onAddressSelected;
  final Function()? nextStep;

  const DeliveryAddressStep({Key? key, this.onAddressSelected, this.nextStep})
      : super(key: key);

  @override
  _DeliveryAddressStepState createState() => _DeliveryAddressStepState();
}

class _DeliveryAddressStepState extends State<DeliveryAddressStep> {
  final TextEditingController addressController = TextEditingController();
  List<String>? savedAddress;

  @override
  void initState() {
    super.initState();
    _fetchUserAddress();
  }

  // SIMULATE FETCHING USER ADDRESS FROM DB/API
  Future<void> _fetchUserAddress() async {
    // TODO: Replace with actual database/API call
    String storedJson =
        '["Kiambu, Githunguri","07345678908"]'; // Example stored address
    setState(() {
      savedAddress = List<String>.from(jsonDecode(storedJson));
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          "Select or Enter Delivery Address",
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 10),

        // DISPLAY SAVED ADDRESS
        if (savedAddress != null)
          Card(
            elevation: 4,
            child: Padding(
              padding: const EdgeInsets.all(12.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    savedAddress![0], // Address
                    style: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    "Phone: ${savedAddress![1]}", // Phone number
                    style: const TextStyle(fontSize: 14),
                  ),
                ],
              ),
            ),
          ),

        const SizedBox(height: 10),

        const Text("Or Enter a New Address:"),
        TextField(
          controller: addressController,
          decoration: const InputDecoration(labelText: "Address"),
        ),

        const SizedBox(height: 10),
        CustomButton(
          text: 'Proceed to Delivery Options',
          onPressed: () {
            String enteredAddress = addressController.text.trim();

            if (enteredAddress.isNotEmpty) {
              widget.onAddressSelected!(enteredAddress);
            } else if (savedAddress != null) {
              widget.onAddressSelected!(savedAddress![0]); // Use stored address
            } else {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text("Please enter an address!")),
              );
              return;
            }

            widget.nextStep!();
          },
        ),
      ],
    );
  }
}
