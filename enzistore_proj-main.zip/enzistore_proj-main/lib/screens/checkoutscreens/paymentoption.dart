import 'package:enzi_hardware_store/components/custom_button.dart';
import 'package:flutter/material.dart';

class PaymentMethodStep extends StatefulWidget {
  final Function(String)? onPaymentSelected;
  final Function()? nextstep;
  final double totalAmount; // Total from cart summary

  const PaymentMethodStep({
    Key? key,
    this.onPaymentSelected,
    this.nextstep,
    required this.totalAmount, // Required total amount
  }) : super(key: key);

  @override
  State<PaymentMethodStep> createState() => _PaymentMethodStepState();
}

class _PaymentMethodStepState extends State<PaymentMethodStep> {
  List<String> paymentMethods = ["M-Pesa", "Pay on Delivery"];
  String selectedPayment = "M-Pesa"; // Default selection
  TextEditingController amountController = TextEditingController();
  String errorMessage = "";

  void validatePayment() {
    if (selectedPayment == "M-Pesa") {
      double enteredAmount = double.tryParse(amountController.text) ?? 0.0;

      if (enteredAmount < widget.totalAmount) {
        setState(() {
          errorMessage =
              "Insufficient amount! You need Ksh ${widget.totalAmount}";
        });
        return;
      }
    }

    // If validation passes, proceed
    widget.nextstep?.call();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          "Select Payment Method",
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 10),

        // Payment Method Selection
        Column(
          children: [
            ...paymentMethods.map((method) {
              return RadioListTile<String>(
                title: Text(method),
                value: method,
                groupValue: selectedPayment,
                onChanged: (value) {
                  setState(() {
                    selectedPayment = value!;
                    errorMessage = ""; // Clear error when switching methods
                  });
                },
              );
            }).toList(),

            // Show M-Pesa Input if Selected
            if (selectedPayment == "M-Pesa") ...[
              const SizedBox(height: 10),
              TextField(
                controller: amountController,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  labelText: "Enter Amount",
                  border: OutlineInputBorder(),
                ),
              ),
            ],

            const SizedBox(height: 10),

            // Error Message
            if (errorMessage.isNotEmpty)
              Text(
                errorMessage,
                style: const TextStyle(
                    color: Colors.red, fontWeight: FontWeight.bold),
              ),

            const SizedBox(height: 10),

            // Proceed Button
            CustomButton(
              text: 'Place Order',
              onPressed: validatePayment, // Validate before proceeding
            ),
          ],
        ),
      ],
    );
  }
}
