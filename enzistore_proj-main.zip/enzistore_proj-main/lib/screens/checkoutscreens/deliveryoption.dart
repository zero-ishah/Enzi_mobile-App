import 'package:enzi_hardware_store/components/custom_button.dart';
import 'package:flutter/material.dart';

class DeliveryOptionStep extends StatefulWidget {
  final Function(String)? onOptionSelected;
  final Function()? nextStep;

  const DeliveryOptionStep({Key? key, this.onOptionSelected, this.nextStep})
      : super(key: key);

  @override
  State<DeliveryOptionStep> createState() => _DeliveryOptionStepState();
}

class _DeliveryOptionStepState extends State<DeliveryOptionStep> {
  List<String> deliveryOptions = [
    "Standard Delivery",
    "Express Delivery",
    "In Shop Pickup"
  ];

  String selectedOption =
      "Standard Delivery"; // Keep track of the selected option

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Column(
          children: [
            ...deliveryOptions.map((option) {
              return RadioListTile<String>(
                title: Text(option),
                value: option,
                groupValue: selectedOption,
                onChanged: (value) {
                  setState(() {
                    selectedOption = value!;
                  });
                  widget.onOptionSelected?.call(value!);
                },
              );
            }).toList(),
            CustomButton(
              text: 'Proceed to Payment Options',
              onPressed: () {
                widget.nextStep?.call();
              },
            ),
          ],
        ),
      ],
    );
  }
}
