import 'package:enzi_hardware_store/components/custom_button.dart';
import 'package:enzi_hardware_store/screens/checkoutscreens/deliveryaddress.dart';
import 'package:enzi_hardware_store/screens/checkoutscreens/deliveryoption.dart';
import 'package:enzi_hardware_store/screens/checkoutscreens/paymentoption.dart';
import 'package:enzi_hardware_store/utils/auth_service.dart';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class CartPage extends StatefulWidget {
  @override
  _CartPageState createState() => _CartPageState();
}

class _CartPageState extends State<CartPage> {
  final supabase = Supabase.instance.client;
  List<Map<String, dynamic>> cartItems = [];
  Set<int> selectedItems = {};
  int currentStep = 0; // Step tracker for the bottom sheet

  var deliveryAddress = '';
  var deliveryOption = '';
  var paymentMethod = '';
  bool _isLoading = false; // TRACK LOADING STATE

  @override
  void initState() {
    super.initState();
    fetchCartItems();
  }

  Future<void> fetchCartItems() async {
    final userId = supabase.auth.currentUser!.id;

    final response = await supabase
        .from('cart')
        .select('*, products!inner(name, selling_price, image_url)')
        .eq('user_id', userId);

    setState(() {
      cartItems = List<Map<String, dynamic>>.from(response);
    });
  }

  void toggleSelection(int cartId) {
    setState(() {
      if (selectedItems.contains(cartId)) {
        selectedItems.remove(cartId);
      } else {
        selectedItems.add(cartId);
      }
    });

    if (selectedItems.isNotEmpty) {
      showDynamicBottomSheet(); // Start the dynamic flow
    }
  }

  double calculateTotal() {
    return cartItems
        .where((item) => selectedItems.contains(item['cart_id']))
        .fold(0.0, (sum, item) {
      double price =
          (item['price'] ?? 0).toDouble(); // Ensure price is not null
      int quantity =
          (item['quantity'] ?? 0).toInt(); // Ensure quantity is not null
      return sum + (price * quantity);
    });
  }

  void showDynamicBottomSheet() {
    showModalBottomSheet(
      context: context,
      isDismissible: true,
      isScrollControlled: true, // Ensure full height for better navigation
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            return Container(
              padding: const EdgeInsets.all(16),
              height: 400,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    _getStepTitle(),
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 20),
                  Expanded(
                      child:
                          _getStepContent(setModalState)), // Pass setModalState
                ],
              ),
            );
          },
        );
      },
    ).whenComplete(() {
      setState(() {
        currentStep = 0; // Reset step when bottom sheet closes
      });
    });
  }

  String _getStepTitle() {
    switch (currentStep) {
      case 0:
        return '';
      case 1:
        return 'Select Delivery Address';
      case 2:
        return 'Choose Delivery Option';
      case 3:
        return 'Select Payment Method';
      default:
        return '';
    }
  }

  Widget _getStepContent(Function setModalState) {
    switch (currentStep) {
      case 0:
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text("Order Summary",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            ...selectedItems.map((id) {
              final item = cartItems.firstWhere((i) => i['cart_id'] == id);
              return Text(
                  "${item['products']['name']} x${item['quantity']} - Kshs ${item['price'] * item['quantity']}");
            }),
            const SizedBox(height: 10),
            Text("Total: Kshs ${calculateTotal().toStringAsFixed(2)}",
                style:
                    const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const Spacer(),
            CustomButton(
                text: 'Proceed to Delivery Address',
                onPressed: () {
                  setModalState(() {
                    currentStep++;
                  });
                })
          ],
        );

      case 1:
        return DeliveryAddressStep(
          nextStep: () {
            setModalState(() {
              currentStep++;
            });
          },
          onAddressSelected: (address) {
            setModalState(() {
              deliveryAddress = address;
            });
          },
        );

      case 2:
        return DeliveryOptionStep(
          nextStep: () {
            setModalState(() {
              currentStep++;
            });
          },
          onOptionSelected: (option) {
            setModalState(() {
              deliveryOption = option;
            });
          },
        );

      case 3:
        return PaymentMethodStep(
          onPaymentSelected: (method) {
            setModalState(() {
              paymentMethod = method;
            });
          },
          nextstep: () {
            print('Delivery Address: $deliveryAddress');
            print('Delivery Option: $deliveryOption');
            print('Payment Method: $paymentMethod');

            Future.delayed(const Duration(milliseconds: 200), () {
              _placeOrder(); // CALL FUNCTION TO PLACE ORDER
            });
          },
          totalAmount: calculateTotal(),
        );

      default:
        return Container(); // Fallback for unknown step
    }
  }

  void _placeOrder() async {
    setState(() {
      _isLoading = true; // SHOW LOADING INDICATOR
    });

    bool success = await placeOrder(); // YOUR FUNCTION TO INSERT INTO DB

    setState(() {
      _isLoading = false; // HIDE LOADING INDICATOR
    });

    if (success) {
      Navigator.pop(context); // CLOSE MODAL
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Your order has been placed successfully!'),
          backgroundColor: Colors.green,
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Failed to place order. Try again.'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  void updateQuantity(int cartId, int newQuantity) async {
    print("Updating quantity for cart_id: $cartId to $newQuantity");

    final response = await supabase
        .from('cart')
        .update({'quantity': newQuantity}).eq('cart_id', cartId);

    print("Update response: $response");

    fetchCartItems(); // Refresh the cart after updating
  }

  void deleteCartItem(int cartId) async {
    await supabase.from('cart').delete().eq('cart_id', cartId);

    fetchCartItems();
  }

  Future<bool> placeOrder() async {
    try {
      final userId = supabase.auth.currentUser!.id;
      final totalAmount = calculateTotal();
      final trackingNumber = generateTrackingNumber();

      print('Inserting into Order table');

      // ✅ Step 1: Insert into `orders` table
      final orderResponse = await supabase
          .from('orders')
          .insert({
            'user_id': userId,
            'product_id': cartItems.firstWhere((item) =>
                selectedItems.contains(item['cart_id']))['product_id'],
            'shipping_address': deliveryAddress,
            'payment_method': paymentMethod,
            'total_amount': totalAmount,
            'order_status': 'Pending',
            'payment_status': 'Unpaid',
            'tracking_number': trackingNumber,
            'order_date': DateTime.now().toIso8601String(),
          })
          .select('order_id')
          .single();

      if (orderResponse == null || !orderResponse.containsKey('order_id')) {
        return false; // Order failed
      }

      final orderId = orderResponse['order_id'];

      print('Inserting into oder items ');

      // ✅ Step 2: Insert each item into `order_items` table
      for (var id in selectedItems) {
        final item = cartItems.firstWhere((i) => i['cart_id'] == id);
        final productId = item['product_id'];
        final quantity = item['quantity'];
        final sellingPrice = item['price'];
        // final costPrice = item['cost_price'];

        await supabase.from('order_items').insert({
          'order_id': orderId,
          'product_id': productId,
          'quantity': quantity,
          'selling_price': sellingPrice,
          // 'cost_price': costPrice,
        });

        print('deducting the quantity');

        // ✅ Deduct quantity from inventory
        await supabase.rpc('deduct_product_quantity', params: {
          'p_product_id': productId,
          'p_quantity': quantity,
        });
      }

      print('Moving order to history');

      // ✅ Step 3: Move order details to `history`
      for (var id in selectedItems) {
        final item = cartItems.firstWhere((i) => i['cart_id'] == id);
        final productId = item['product_id'];
        final quantity = item['quantity'];
        final sellingPrice = item['price'];
        // final costPrice = item['cost_price'];
        final totalRevenue = sellingPrice * quantity;
        // final totalCost = costPrice * quantity;
        // final profitLoss = totalRevenue - totalCost;

        await supabase.from('history').insert({
          'user_id': userId,
          'order_id': orderId,
          'product_id': productId,
          'quantity': quantity,
          'selling_price': sellingPrice,
          // 'cost_price': costPrice,
          'total_revenue': totalRevenue,
          // 'total_cost': totalCost,
          // 'profit_loss': profitLoss,
          'order_date': DateTime.now().toIso8601String(),
        });
      }

      print("Clearing the cart after order placement");

      // ✅ Step 4: Clear the cart after order placement
      await supabase
          .from('cart')
          .delete()
          .inFilter('cart_id', selectedItems.toList());

      return true; // Order placed successfully
    } catch (e) {
      print("Order placement error: $e");
      return false;
    }
  }

// Function to generate a unique tracking number
  String generateTrackingNumber() {
    final now = DateTime.now();
    return "TRK${now.millisecondsSinceEpoch}";
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Your Cart")),
      body: ListView.builder(
        itemCount: cartItems.length,
        itemBuilder: (context, index) {
          final item = cartItems[index];
          final product = item['products'];

          return Card(
            margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            elevation: 3,
            child: Padding(
              padding: const EdgeInsets.all(10),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Checkbox(
                    value: selectedItems.contains(item['cart_id']),
                    onChanged: (value) => toggleSelection(item['cart_id']),
                    activeColor: Theme.of(context).primaryColor,
                  ),
                  const SizedBox(width: 5),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(5),
                    child: Image.network(
                      product['image_url'] ?? 'https://placehold.co/600x400',
                      width: 60,
                      height: 60,
                      fit: BoxFit.cover,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(product['name'],
                            style: const TextStyle(
                                fontSize: 16, fontWeight: FontWeight.bold)),
                        Text("Variant: ${item['variant'] ?? 'Default'}",
                            style: const TextStyle(
                                fontSize: 14, color: Colors.grey)),
                        const SizedBox(height: 5),
                        Text("Kshs. ${item['price']}",
                            style: const TextStyle(
                                fontSize: 14, fontWeight: FontWeight.bold)),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            IconButton(
                              icon:
                                  const Icon(Icons.remove, color: Colors.grey),
                              onPressed: () {
                                if (item['quantity'] > 1) {
                                  updateQuantity(
                                      item['cart_id'], item['quantity'] - 1);
                                }
                              },
                            ),
                            Text("${item['quantity']}",
                                style: const TextStyle(
                                    fontSize: 16, fontWeight: FontWeight.bold)),
                            IconButton(
                              icon: const Icon(Icons.add, color: Colors.blue),
                              onPressed: () {
                                updateQuantity(
                                    item['cart_id'], item['quantity'] + 1);
                              },
                            ),
                            IconButton(
                              icon: const Icon(Icons.delete, color: Colors.red),
                              onPressed: () {
                                deleteCartItem(item['cart_id']);
                              },
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
