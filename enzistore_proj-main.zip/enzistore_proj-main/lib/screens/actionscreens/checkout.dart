import 'package:flutter/material.dart';

class CheckoutPage extends StatelessWidget {
  final int productId;
  final String productName;
  final double productPrice;
  final String productImage;
  final String selectedVariant;

  const CheckoutPage({
    super.key,
    required this.productId,
    required this.productName,
    required this.productPrice,
    required this.productImage,
    required this.selectedVariant,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Checkout")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // PRODUCT IMAGE
            Image.network(
              productImage,
              height: 200,
              width: double.infinity,
              fit: BoxFit.cover,
            ),
            const SizedBox(height: 16),

            // PRODUCT NAME & VARIANT
            Text(productName,
                style:
                    const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            Text("Variant: $selectedVariant",
                style: const TextStyle(fontSize: 16, color: Colors.grey)),

            const SizedBox(height: 10),

            // PRICE
            Text("Kshs. $productPrice",
                style: const TextStyle(fontSize: 18, color: Colors.green)),

            const SizedBox(height: 20),

            // PAYMENT BUTTON
            ElevatedButton(
              onPressed: () {
                // IMPLEMENT PAYMENT LOGIC HERE
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text("Proceeding to payment...")),
                );
              },
              style: ElevatedButton.styleFrom(backgroundColor: Colors.blue),
              child: const Text("Proceed to Pay"),
            ),
          ],
        ),
      ),
    );
  }
}

// final response = await supabase
//         .from('cart')
//         .select('*, products!inner(product_id, name, selling_price,image_url)')
//         .eq('user_id', userId)
//         .limit(1);
