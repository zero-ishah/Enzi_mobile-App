import 'package:enzi_hardware_store/components/terms_conditions.dart';
import 'package:enzi_hardware_store/providers/theme_provide.dart';
import 'package:enzi_hardware_store/screens/detailscreen/deliveryaddresspage.dart';
import 'package:enzi_hardware_store/utils/auth_service.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';

class Account extends StatefulWidget {
  const Account({super.key});

  @override
  State<Account> createState() => _AccountState();
}

class _AccountState extends State<Account> {
  final SupabaseClient supabase = Supabase.instance.client;
  Map<String, dynamic>? userInfo;
  int wishlistCount = 0;
  int orderCount = 0;
  bool isDarkMode = false;

  Future<void> _getUserInfo() async {
    try {
      final user = supabase.auth.currentUser;
      if (user != null) {
        final userInfoResponse =
            await supabase.from('users').select('*').single();
        final wishlistResponse =
            await supabase.from('wishlist').select().eq('user_id', user.id);
        final orderResponse =
            await supabase.from('orders').select().eq('user_id', user.id);

        setState(() {
          userInfo = userInfoResponse;
          wishlistCount = wishlistResponse.length;
          orderCount = orderResponse.length;
        });
      }
    } catch (e) {
      AuthService(supabase)
          .showPopup(context, 'Error fetching user info: $e', false);
    }
  }

  Future<void> _pickAndUploadImage() async {
    final ImagePicker picker = ImagePicker();
    final XFile? image = await picker.pickImage(source: ImageSource.gallery);
    if (image == null) return;

    try {
      final file = File(image.path);
      final fileName =
          '${userInfo?['user_id']}_${DateTime.now().millisecondsSinceEpoch}.jpg';
      final response =
          await supabase.storage.from('profile_images').upload(fileName, file);
      print(response);
      final imageUrl =
          supabase.storage.from('profile_images').getPublicUrl(fileName);

      print(imageUrl);

      await supabase
          .from('users')
          .update({'profile_image': imageUrl}).match({'user_id': userInfo?['user_id']});
      setState(() {
        userInfo?['profile_image'] = imageUrl;
      });
    } catch (e) {
      AuthService(supabase)
          .showPopup(context, 'Error uploading image: $e', false);
      print("Error uploading profile photo: $e");
    }
  }

  Future<void> _showPasswordDialog() async {
    try {
      final user = supabase.auth.currentUser;
      if (user == null) return;

      final response = await supabase
          .from('auth')
          .select('password')
          .eq('user_id', user.id)
          .single();

      String password = response['password'];

      showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: const Text('Your Password'),
            content: Text(password),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: const Text('Close'),
              ),
              TextButton(
                onPressed: () {
                  // AuthService(supabase).resetPassword(context);
                },
                child: const Text('Reset Password'),
              ),
            ],
          );
        },
      );
    } catch (e) {
      AuthService(supabase)
          .showPopup(context, 'Error retrieving password', false);
    }
  }

  @override
  void initState() {
    super.initState();
    _getUserInfo();
  }

  @override
  Widget build(BuildContext context) {
    final themeProvider = ThemeProvide();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile'),
      ),
      body: userInfo == null
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              children: [
                // PROFILE PIC

                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    GestureDetector(
                      onTap: _pickAndUploadImage,
                      child: CircleAvatar(
                        radius: 40,
                        backgroundImage: userInfo?['profile_image'] != null
                            ? NetworkImage(userInfo!['profile_image'])
                            : null,
                        child: userInfo?['profile_image'] == null
                            ? const Icon(Icons.person, size: 40)
                            : null,
                      ),
                    ),
                    const SizedBox(width: 16),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          userInfo?['first_name'] ?? 'Unknown',
                          style: const TextStyle(
                              fontSize: 20, fontWeight: FontWeight.bold),
                        ),
                        Row(
                          children: [
                            const Icon(Icons.favorite),
                            const SizedBox(width: 4),
                            Text('$wishlistCount items'),
                            const SizedBox(width: 16),
                            const Icon(Icons.shopping_bag),
                            const SizedBox(width: 4),
                            Text('$orderCount orders'),
                          ],
                        ),
                        Row(
                          children: [
                            ElevatedButton(
                              onPressed: _pickAndUploadImage,
                              child: const Text('Update'),
                            ),
                            const SizedBox(width: 16),
                            OutlinedButton(
                              onPressed: () {},
                              child: const Text('Remove'),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
                const SizedBox(
                  height: 20,
                ),

                ////////////////////////
                ListTile(
                  title: const Text('Theme'),
                  trailing: Switch(
                    value: isDarkMode,
                    onChanged: (value) {
                      setState(() {
                        isDarkMode = value;
                      });
                      Provider.of<ThemeProvide>(context, listen: false)
                          .toggleTheme();
                    },
                  ),
                ),
                ListTile(
                  title: const Text('Password'),
                  trailing: const Icon(Icons.arrow_forward_ios),
                  onTap: _showPasswordDialog,
                ),
                ListTile(
                  title: const Text('Delivery Address'),
                  trailing: const Icon(Icons.arrow_forward_ios),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => DeliveryAddressPage(),
                      ),
                    );
                  },
                ),
                ListTile(
                  title: const Text('Terms and conditions'),
                  trailing: const Icon(Icons.arrow_forward_ios),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const TermsConditions()),
                    );
                  },
                ),
                ListTile(
                  title: const Text('Log out'),
                  trailing: const Icon(Icons.arrow_forward_ios),
                  onTap: () {
                    AuthService(supabase).signOut(context);
                  },
                ),
              ],
            ),
    );
  }
}
