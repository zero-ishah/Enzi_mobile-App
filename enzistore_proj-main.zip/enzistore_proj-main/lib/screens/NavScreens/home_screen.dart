import 'package:enzi_hardware_store/components/category_card.dart';
import 'package:enzi_hardware_store/components/product_card.dart';
import 'package:enzi_hardware_store/screens/detailscreen/categorydetails.dart';
import 'package:enzi_hardware_store/utils/auth_service.dart';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../components/homescreen/header.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final SupabaseClient supabase = Supabase.instance.client;
  List<String> searchSuggestions = [];
  List<Map<String, dynamic>> featuredProducts = [];
  List<Map<String, dynamic>> categories = [];
  List<Map<String, dynamic>> popularProducts = [];

  @override
  void initState() {
    super.initState();
    _fetchData();
  }

  /// FETCH DATA FROM SUPABASE
  Future<void> _fetchData() async {
    try {
      // FETCH SEARCH SUGGESTIONS
      final searchResponse = await supabase.from('products').select('name');

      // FETCH FEATURED PRODUCTS WITH FULL DETAILS
      final featuredResponse = await supabase
          .from('featured_products')
          .select('product_id, products!inner(name, selling_price, image_url)');

      // FETCH CATEGORIES
      final categoriesResponse = await supabase.from('categories').select('*');

      // FETCH POPULAR PRODUCTS WITH FULL DETAILS
      final popularResponse = await supabase
          .from('popular_products')
          .select('product_id, products!inner(name, selling_price, image_url)');

      setState(() {
        searchSuggestions = searchResponse
            .map<String>((item) => item['name'].toString())
            .toList();

        featuredProducts = List<Map<String, dynamic>>.from(featuredResponse);
        categories = List<Map<String, dynamic>>.from(categoriesResponse);
        popularProducts = List<Map<String, dynamic>>.from(popularResponse);

        print(categories);
      });
    } catch (error) {
      AuthService(supabase)
          .showPopup(context, 'Error fetching data: $error', false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
        children: [
          const Header(),

          // SEARCH BAR
          Padding(
            padding: const EdgeInsets.all(10.0),
            child: SearchAnchor.bar(
              suggestionsBuilder: (context, controller) {
                return searchSuggestions
                    .where((suggestion) => suggestion
                        .toLowerCase()
                        .contains(controller.text.toLowerCase()))
                    .map((suggestion) => ListTile(
                          title: Text(suggestion),
                          onTap: () => controller.text = suggestion,
                        ))
                    .toList();
              },
            ),
          ),

          // FEATURED PRODUCTS
          _buildSectionTitle('Featured Products'),
          _buildFeaturedGridList(featuredProducts),

          // CATEGORIES
          _buildSectionTitle('Categories'),
          _buildHorizontalList(categories),

          // POPULAR / RECENT PRODUCTS
          _buildSectionTitle('Popular Products'),
          _buildFeaturedGridList(popularProducts),
        ],
      ),
    );
  }

  /// SECTION TITLE
  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      child: Text(title,
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
    );
  }

  /// GRID LIST (FOR FEATURED PRODUCTS)
  Widget _buildFeaturedGridList(List<Map<String, dynamic>> items) {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: items.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        childAspectRatio: 0.8,
      ),
      itemBuilder: (context, index) {
        final productData =
            items[index]['products']; // Access nested 'products' key

        if (productData == null) {
          return const SizedBox(); // Skip rendering if productData is null
        }

        return ProductCard(
          productId: items[index]['product_id'],
          imageUrl: productData['image_url'] ?? '',
          name: productData['name'] ?? 'Unknown',
          price: double.tryParse(
                  productData['selling_price']?.toString() ?? '0') ??
              0,
          
        );
      },
    );
  }

  /// HORIZONTAL LIST (FOR CATEGORIES )
  Widget _buildHorizontalList(List<Map<String, dynamic>> items) {
    return SizedBox(
      height: 120,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: items.length,
        itemBuilder: (context, index) {
          return CategoryCard(
            category: items[index]['category'] ?? 'Category',
            iconUrl: items[index]['iconUrl'] ?? '',
            bgColor: Theme.of(context).cardColor,
            categoryId: items[index]['category_id'],
            onTap: (categoryId) {
              // NAVIGATE TO CATEGORY PRODUCTS PAGE
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => CategoryProductsPage(
                      categoryName: items[index]['category'],
                      categoryId: categoryId),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
